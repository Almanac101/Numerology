from django.apps import AppConfig


class LandinggConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'landingg'
