from django.db import models
from embed_video.fields import EmbedVideoField

# Create your models here.
class site_visitor (models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=30, default= 'this is it')

    def _str_(self):
        return self.site_visitor


class Videos(models.Model):
    video=  EmbedVideoField()

class AlphaGuide(models.Model):
    Letter_Position = models.CharField(max_length=30)
    Attribute = models.TextField(max_length=1500)    

    def _str_(self):
        return self.Attributes
        

class Alphatables(AlphaGuide):
    pass