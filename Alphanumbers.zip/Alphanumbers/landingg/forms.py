from django.forms import ModelForm
from .models import Alphanumeric

class name(ModelForm):
    class Meta:
        model = Alphanumeric 
        fields = '__all__'
