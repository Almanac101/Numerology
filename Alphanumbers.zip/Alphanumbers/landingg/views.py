from lib2to3.refactor import get_all_fix_names
from tkinter import Entry
from django.shortcuts import render
from django.http import HttpResponse
from django.template import RequestContext
from django.db import models
from django.template.defaulttags import csrf_token
from .models import *
from django.http import HttpResponseRedirect
from landingg.models import site_visitor
from.models import AlphaGuide

# Create your views here.
def home_view(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = name(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/thanks/')
    # if a GET (or any other method) we'll create a blank for
    return render(request, "home_view.html")
# create another view for the Alphanumeric operations

def results(request):
    if request.method=="POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
       # print(name, email)
        ins = site_visitor(name=name,email=email)
        ins.save()
        name=list(name)
        #ins = Alphanumeric(name=name, email=email)
        try:
            if name[0] == 'A' or 'J' or 'S':
                thisresult= AlphaGuide.objects.get(id=234)
            elif name[0] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=235)
            elif name[0] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=236)
            elif name[0] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=237)
            elif name[0] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=238)
            elif name[0] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=239)
            elif name[0] == 'G' or 'P' or 'Y':
                thisresult= Alphaguide.objects.get(id=240)
            elif name[0] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=241)
            elif name[0] == 'I' or 'R':
                thisresult= Alphaguide.objects.get(id=242)
    
        
            elif name[1] == 'A' or 'J' or 'S':
                thisresult= AlphaGuide.objects.get(id=243)
            elif name[1] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=244)
            elif name[1] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=245)
            elif name[1] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=246)
            elif name[1] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=247)
            elif name[1] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=248)
            elif name[1] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=249)
            elif name[1] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=250)
            elif name[1] == 'I' or 'R':
                thisresult=  AlphaGuide.objects.get(id=251)

        
            elif name[2] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=252)
            elif name[2] == 'B' or 'K' or 'T':
                thisresult=AlphaGuide.objects.get(id=253)
            elif name[2] == 'C' or 'L' or 'U':
                thisresult=AlphaGuide.objects.get(id=254)
            elif name[2] == 'D' or 'M' or 'V':
                thisresult=AlphaGuide.objects.get(id=255)
            elif name[2] == 'E' or 'N' or 'W':
                thisresult=AlphaGuide.objects.get(id=265)
            elif name[2] == 'F' or 'O' or 'X':
                thisresult=AlphaGuide.objects.get(id=257)
            elif name[2] == 'G' or 'P' or 'Y':
                thisresult=AlphaGuide.objects.get(id=258)
            elif name[2] == 'H' or 'Q' or 'Z':
                thisresult=AlphaGuide.objects.get(id=259)
            elif name[2] == 'I' or 'R':
                thisresult=AlphaGuide.objects.get(id=260)

       
            elif name[3] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=262)
            elif name[3] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=263)
            elif name[3] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=264)
            elif name[3] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=265)
            elif name[3] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=266)
            elif name[3] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=267)
            elif name[3] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=268)
            elif name[3] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=269)
            elif name[3] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=270)

       
            elif name[4] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=271)
            elif name[4] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=272)
            elif name[4] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=273)
            elif name[4] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=274)
            elif name[4] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=275)
            elif name[4] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=276)
            elif name[4] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=277)
            elif name[4] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=278)
            elif name[4] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=279)

        
            elif name[5] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=280)
            elif name[5] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=281)
            elif name[5] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=282)
            elif name[5] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=283)
            elif name[5] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=284)
            elif name[5] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=285)
            elif name[5] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=286)
            elif name[5] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=287)
            elif name[5] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=288)

            elif name[6] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=289)
            elif name[6] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=270)
            elif name[6] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=271)
            elif name[6] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=272)
            elif name[6] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=273)
            elif name[6] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=274)
            elif name[6] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=275)
            elif name[6] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=276)
            elif name[6] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=277)

       
            elif name[7] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=288)
            elif name[7] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=289)
            elif name[7] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=290)
            elif name[7] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=291)
            elif name[7] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=292)
            elif name[7] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=293)
            elif name[7] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=294)
            elif name[7] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=295)
            elif name[7] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=296)

            elif name[8] == 'A' or 'S' or 'J':
                thisresult= AlphaGuide.objects.get(id=297)
            elif name[8] == 'B' or 'K' or 'T':
                thisresult= AlphaGuide.objects.get(id=298)
            elif name[8] == 'C' or 'L' or 'U':
                thisresult= AlphaGuide.objects.get(id=299)
            elif name[8] == 'D' or 'M' or 'V':
                thisresult= AlphaGuide.objects.get(id=300)
            elif name[8] == 'E' or 'N' or 'W':
                thisresult= AlphaGuide.objects.get(id=301)
            elif name[8] == 'F' or 'O' or 'X':
                thisresult= AlphaGuide.objects.get(id=302)
            elif name[8] == 'G' or 'P' or 'Y':
                thisresult= AlphaGuide.objects.get(id=303)
            elif name[8] == 'H' or 'Q' or 'Z':
                thisresult= AlphaGuide.objects.get(id=304)
            elif name[8] == 'I' or 'R':
                thisresult= AlphaGuide.objects.get(id=305)
            else:
                pass
        
        except AlphaGuide.DoesNotExist:
            pass

        return render(request, 'results.html' ,{'thisresult':thisresult})

# create another view to calculate the site visitor's alphanumeric numbers 

